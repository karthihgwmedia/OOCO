<?php
//////eshop base//////
$currentconditions=array('new', 'used', 'refurbished', 'second hand');
?>