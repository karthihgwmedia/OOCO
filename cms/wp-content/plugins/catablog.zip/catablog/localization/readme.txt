This file contains instructions and information for people who want to translate CataBlog into another local.

Please read this page to learn how to translate a file
http://codex.wordpress.org/Translating_WordPress

The included catablog.po file should be duplicated and renamed with the appropriate localization suffix.

When you are done, please email me the translated PO and MO files.

Please feel free to contact me with questions or send me your translation files, so I may integrate it into the next version of CataBlog.
http://www.illproductions.com/contact/



Thanks for your support,

  macguru2000